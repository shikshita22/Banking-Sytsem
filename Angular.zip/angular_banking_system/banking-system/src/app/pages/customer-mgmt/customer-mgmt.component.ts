import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';
import { StoreService } from '../../core/services/store.service';
import { UtilsService } from '../../core/services/utils.service';
import { ToastService } from '../../core/services/toast.service';
import { ModalService } from '../../core/services/modal.service';
import { User } from '../../core/models/bank.models';

@Component({
  selector: 'app-customer-mgmt',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-enter" *ngIf="user">
      <div class="page-header">
        <div>
          <h1>Customer Management</h1>
          <p>Search, inspect, and manage customer accounts and statuses</p>
        </div>
      </div>

      <div class="card mb-lg">
        <div class="filter-bar">
          <div class="form-group" style="margin-bottom:0;flex:1">
            <input type="text" class="form-input" name="search" [(ngModel)]="searchQuery" (input)="filterCustomers()" placeholder="Search by name, email, phone, or User ID...">
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h3>Customers ({{ filteredCustomers.length }})</h3>
        </div>
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Status</th>
                <th>Joined</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngIf="filteredCustomers.length === 0">
                <td colspan="7" class="text-center p-xl">
                  <div class="empty-state">
                    <span class="material-icons-round">people</span>
                    <h3>No customers found</h3>
                  </div>
                </td>
              </tr>
              <tr *ngFor="let c of filteredCustomers">
                <td class="font-mono text-sm font-semibold">{{ c.userId }}</td>
                <td class="font-semibold">{{ c.firstName }} {{ c.lastName }}</td>
                <td>{{ c.email }}</td>
                <td>{{ c.phone }}</td>
                <td><span class="badge" [ngClass]="'badge-' + getStatusBadgeClass(c.status)">{{ c.status }}</span></td>
                <td>{{ formatDate(c.createdAt) }}</td>
                <td>
                  <button class="btn btn-outline btn-sm" (click)="toggleUserStatus(c)">
                    <span class="material-icons-round">{{ c.status === 'ACTIVE' ? 'block' : 'check_circle' }}</span>
                    {{ c.status === 'ACTIVE' ? 'Freeze' : 'Activate' }}
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class CustomerMgmtComponent implements OnInit {
  user: User | null = null;
  customers: User[] = [];
  filteredCustomers: User[] = [];
  searchQuery = '';

  constructor(
    private authService: AuthService,
    private storeService: StoreService,
    private utilsService: UtilsService,
    private toastService: ToastService,
    private modalService: ModalService
  ) {}

  ngOnInit() {
    this.user = this.authService.getCurrentUser();
    if (this.user) {
      this.loadCustomers();
    }
  }

  loadCustomers() {
    this.customers = this.storeService.getAll<User>('users').filter(u => u.role === 'CUSTOMER');
    this.filterCustomers();
  }

  filterCustomers() {
    const q = this.searchQuery.trim().toLowerCase();
    if (!q) {
      this.filteredCustomers = [...this.customers];
      return;
    }
    this.filteredCustomers = this.customers.filter(c =>
      c.userId.toLowerCase().includes(q) ||
      `${c.firstName} ${c.lastName}`.toLowerCase().includes(q) ||
      c.email.toLowerCase().includes(q) ||
      c.phone.includes(q)
    );
  }

  formatDate(dateStr: string): string {
    return this.utilsService.formatDate(dateStr);
  }

  getStatusBadgeClass(status: string): string {
    return this.utilsService.getStatusBadgeClass(status);
  }

  toggleUserStatus(cust: User) {
    const newStatus = cust.status === 'ACTIVE' ? 'FROZEN' : 'ACTIVE';
    this.modalService.confirm('Change Customer Status', `Are you sure you want to change status of ${cust.firstName} ${cust.lastName} to ${newStatus}?`, () => {
      this.storeService.updateUser(cust.userId, { status: newStatus });
      this.toastService.success('Status Updated', `User ${cust.userId} is now ${newStatus}`);
      this.loadCustomers();
    });
  }
}
