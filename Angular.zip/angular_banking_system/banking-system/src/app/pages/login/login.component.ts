import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';
import { ModalService } from '../../core/services/modal.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  template: `
    <div class="auth-page auth-login-page">
      <div class="auth-container">
        <div class="auth-logo">
          <div class="logo-icon">
            <span class="material-icons-round">account_balance</span>
          </div>
          <h1>ILPBank</h1>
          <p>Your trusted banking partner</p>
        </div>
        <div class="auth-card fade-up">
          <h2>Welcome Back</h2>
          <p>Sign in to access your account</p>

          <div class="login-context">
            <span class="eyebrow">{{ activeRole === 'staff' ? 'Staff & Admin' : 'Customer' }} Login</span>
            <h3>{{ activeRole === 'staff' ? 'Staff portal access' : 'Customer account access' }}</h3>
          </div>

          <form (ngSubmit)="onSubmit()" autocomplete="off" [ngClass]="{ 'shake': isShaking }">
            <div class="form-group">
              <label class="form-label">User ID or Email <span class="text-danger">*</span></label>
              <div class="input-group">
                <span class="input-icon"><span class="material-icons-round">person</span></span>
                <input type="text" class="form-control" name="identifier" [(ngModel)]="identifier"
                       [placeholder]="activeRole === 'staff' ? 'e.g. S0001 or rajesh.kumar@tcs.com' : 'e.g. U0001 or amit.sharma@tcs.com'" required>
              </div>
            </div>

            <div class="form-group">
              <label class="form-label">Password <span class="text-danger">*</span></label>
              <div class="input-group">
                <span class="input-icon"><span class="material-icons-round">lock</span></span>
                <input type="password" class="form-control" name="password" [(ngModel)]="password" placeholder="Enter your password" required>
              </div>
            </div>

            <div class="flex items-center justify-between mb-lg">
              <label class="form-check">
                <input type="checkbox" name="remember" [(ngModel)]="remember"> Remember me
              </label>
              <a (click)="showForgotPassword()" style="cursor:pointer" class="text-sm">Forgot password?</a>
            </div>

            <button type="submit" class="btn btn-primary btn-block btn-lg" [disabled]="isLoading">
              <span class="material-icons-round" [ngClass]="{ 'spin': isLoading }">{{ isLoading ? 'sync' : 'login' }}</span>
              {{ isLoading ? 'Signing in...' : 'Sign In' }}
            </button>
          </form>

          <div class="auth-footer">
            Don't have an account? <a routerLink="/register">Create Account</a>
          </div>
        </div>

        <div class="text-center mt-lg">
          <p class="text-xs text-muted">Demo Credentials</p>
          <p class="text-xs text-muted" (click)="fillDemo('U0001', 'Customer&#64;1234', 'customer')" style="cursor:pointer">Customer: U0001 / Customer&#64;1234</p>
          <p class="text-xs text-muted" (click)="fillDemo('S0001', 'Admin&#64;1234', 'staff')" style="cursor:pointer">Admin: S0001 / Admin&#64;1234</p>
        </div>
      </div>
      <footer class="auth-footer-pane auth-login-footer">
        <div class="auth-footer-support">
          <strong>Need help?</strong>
          <span>Customer Care <a href="tel:18001239876">1800-123-9876</a></span>
          <span>Cards <a href="tel:18004561234">1800-456-1234</a></span>
          <span>Loans <a href="tel:18007894321">1800-789-4321</a></span>
        </div>
        <div class="auth-footer-links">
          <a routerLink="/help">Help & Support</a>
          <a href="#">Privacy Policy</a>
          <a href="#">Terms & Conditions</a>
          <a href="#">Security</a>
        </div>
        <div class="auth-footer-copy">© 2026 ILPBank. All rights reserved. &nbsp; | &nbsp; Banking made simple, secure and accessible.</div>
      </footer>
    </div>
  `
})
export class LoginComponent implements OnInit {
  activeRole: 'customer' | 'staff' = 'customer';
  identifier: string = '';
  password: string = '';
  remember: boolean = false;
  isLoading: boolean = false;
  isShaking: boolean = false;

  constructor(
    private authService: AuthService,
    private toastService: ToastService,
    private modalService: ModalService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    const role = this.route.snapshot.data['role'];
    if (role === 'staff' || role === 'customer') {
      this.activeRole = role;
    }
  }

  fillDemo(id: string, pass: string, role: 'customer' | 'staff') {
    this.activeRole = role;
    this.identifier = id;
    this.password = pass;
  }

  async onSubmit() {
    if (!this.identifier || !this.password) {
      this.toastService.error('Error', 'Please enter User ID/Email and Password');
      return;
    }

    this.isLoading = true;

    // Simulate small network delay
    await new Promise(r => setTimeout(r, 600));

    const result = await this.authService.login(this.identifier, this.password);

    this.isLoading = false;

    if (result.success && result.user) {
      this.toastService.success('Welcome!', `Logged in as ${result.user.firstName} ${result.user.lastName}`);
      if (result.user.role === 'ADMIN') {
        this.router.navigate(['/staff-dashboard']);
      } else {
        this.router.navigate(['/dashboard']);
      }
    } else {
      this.toastService.error('Login Failed', result.error || 'Invalid credentials');
      this.isShaking = true;
      setTimeout(() => this.isShaking = false, 500);
    }
  }

  showForgotPassword() {
    const otp = this.authService.generateOTP();
    this.modalService.alert('Forgot Password', `A password reset OTP has been sent: ${otp} (Simulated). Please contact support to complete reset.`);
  }
}
