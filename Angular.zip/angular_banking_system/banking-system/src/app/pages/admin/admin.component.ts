import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../core/services/auth.service';
import { StoreService } from '../../core/services/store.service';
import { SeedService } from '../../core/services/seed.service';
import { UtilsService } from '../../core/services/utils.service';
import { ToastService } from '../../core/services/toast.service';
import { ModalService } from '../../core/services/modal.service';
import { AuditLog, User } from '../../core/models/bank.models';

@Component({
  selector: 'app-admin-panel',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="page-enter" *ngIf="user">
      <div class="page-header">
        <div>
          <h1>Admin Panel</h1>
          <p>System controls, database management, and audit log inspection</p>
        </div>
        <div class="page-actions">
          <button class="btn btn-secondary" (click)="reseedDatabase()">
            <span class="material-icons-round">refresh</span> Reseed Seed Data
          </button>
          <button class="btn btn-danger" (click)="clearDatabase()">
            <span class="material-icons-round">delete_forever</span> Clear Database
          </button>
        </div>
      </div>

      <div class="card mb-xl">
        <div class="card-header">
          <h3>System Audit Logs ({{ auditLogs.length }})</h3>
        </div>
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Log ID</th>
                <th>User ID</th>
                <th>Action</th>
                <th>Target</th>
                <th>Details</th>
                <th>Timestamp</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let log of auditLogs">
                <td class="font-mono text-sm">{{ log.id }}</td>
                <td class="font-mono text-sm font-semibold">{{ log.userId }}</td>
                <td><span class="badge badge-info">{{ log.action }}</span></td>
                <td class="font-mono text-sm">{{ log.target }}</td>
                <td>{{ log.details }}</td>
                <td class="text-sm text-muted">{{ formatDateTime(log.timestamp) }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class AdminPanelComponent implements OnInit {
  user: User | null = null;
  auditLogs: AuditLog[] = [];

  constructor(
    private authService: AuthService,
    private storeService: StoreService,
    private seedService: SeedService,
    private utilsService: UtilsService,
    private toastService: ToastService,
    private modalService: ModalService
  ) {}

  ngOnInit() {
    this.user = this.authService.getCurrentUser();
    if (this.user) {
      this.loadAuditLogs();
    }
  }

  loadAuditLogs() {
    this.auditLogs = this.storeService.getAuditLogs();
  }

  formatDateTime(dateStr: string): string {
    return this.utilsService.formatDateTime(dateStr);
  }

  async reseedDatabase() {
    this.modalService.confirm('Reseed Data', 'This will reset the database to default seed data. Proceed?', async () => {
      this.storeService.clearAll();
      await this.seedService.loadSeedData();
      this.toastService.success('Database Reseeded', 'Default seed data has been reloaded');
      window.location.reload();
    });
  }

  clearDatabase() {
    this.modalService.confirm('Clear Database', 'Are you sure you want to clear all data? You will be logged out.', () => {
      this.storeService.clearAll();
      this.toastService.info('Cleared', 'Database cleared');
      this.authService.logout();
    }, 'danger');
  }
}
