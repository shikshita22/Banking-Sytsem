import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ToastService } from '../../core/services/toast.service';

@Component({
  selector: 'app-help-support',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-enter">
      <div class="page-header">
        <div>
          <h1>Help & Support</h1>
          <p>Find answers to common questions or reach out to our 24/7 support team</p>
        </div>
      </div>

      <div class="grid grid-2 gap-lg mb-xl">
        <!-- FAQ Accordion -->
        <div class="card">
          <div class="card-header"><h3>Frequently Asked Questions</h3></div>
          <div class="faq-list">
            <div *ngFor="let faq of faqs; let i = index" class="card card-flat p-md mb-sm" (click)="toggleFaq(i)" style="cursor:pointer">
              <div class="flex justify-between items-center">
                <h4 class="text-sm font-semibold mb-0">{{ faq.q }}</h4>
                <span class="material-icons-round text-muted">{{ openFaqIndex === i ? 'expand_less' : 'expand_more' }}</span>
              </div>
              <p *ngIf="openFaqIndex === i" class="text-sm text-secondary mt-sm mb-0 fade-up">{{ faq.a }}</p>
            </div>
          </div>
        </div>

        <!-- Contact Support Form -->
        <div class="card">
          <div class="card-header"><h3>Submit a Complaint</h3></div>
          <form (ngSubmit)="onSubmitTicket()">
            <div class="form-group">
              <label class="form-label">Complaint Type</label>
              <select class="form-select" name="category" [(ngModel)]="complaintType" required>
                <option value="ACCOUNT">Account Services</option>
                <option value="CARDS">Cards & ATM</option>
                <option value="TRANSFERS">Fund Transfer</option>
                <option value="LOANS">Loan Dispute</option>
                <option value="SECURITY">Security / Login</option>
                <option value="OTHER">Other</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Short Description</label>
              <input type="text" class="form-control" name="summary" [(ngModel)]="complaintSummary" placeholder="Briefly describe your complaint" required>
            </div>
            <div class="form-group">
              <label class="form-label">Additional Details</label>
              <textarea class="form-control" name="details" [(ngModel)]="complaintDescription" rows="4" placeholder="Add any extra information or references" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary btn-block">
              <span class="material-icons-round">send</span> Submit Complaint
            </button>
          </form>
        </div>
      </div>
    </div>
  `
})
export class HelpSupportComponent {
  openFaqIndex: number | null = 0;
  complaintType = 'ACCOUNT';
  complaintSummary = '';
  complaintDescription = '';

  faqs = [
    { q: 'How do I reset my NetBanking password?', a: 'Click on "Forgot Password?" on the login page or use the Security section under My Profile after logging in.' },
    { q: 'What is the daily fund transfer limit?', a: 'Standard daily online transfer limit is ₹5,00,000 for Savings accounts and ₹25,00,000 for Current accounts.' },
    { q: 'How can I block a lost debit or credit card?', a: 'Navigate to Debit Cards or Credit Cards in the sidebar menu and click "Block Card" for instant blocking.' },
    { q: 'When will my loan application be approved?', a: 'Loan applications are reviewed by staff within 24-48 business hours. You can track progress under Loan Status.' }
  ];

  constructor(private toastService: ToastService) {}

  toggleFaq(index: number) {
    this.openFaqIndex = this.openFaqIndex === index ? null : index;
  }

  onSubmitTicket() {
    if (!this.complaintType || !this.complaintSummary || !this.complaintDescription) {
      this.toastService.error('Error', 'Please select a complaint type and add a short description');
      return;
    }
    const ticketId = 'CMP' + Math.floor(1000 + Math.random() * 9000);
    this.toastService.success('Complaint Registered', `Complaint ${ticketId} has been submitted. Our team will respond soon.`);
    this.complaintType = 'ACCOUNT';
    this.complaintSummary = '';
    this.complaintDescription = '';
  }
}
