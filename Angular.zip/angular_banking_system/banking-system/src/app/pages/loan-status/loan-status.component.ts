import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';
import { StoreService } from '../../core/services/store.service';
import { UtilsService } from '../../core/services/utils.service';
import { Loan, User } from '../../core/models/bank.models';

@Component({
  selector: 'app-loan-status',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-enter" *ngIf="user">
      <div class="page-header">
        <div>
          <h1>Loan Status</h1>
          <p>Track your loan applications, approvals, and repayment schedules</p>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h3>My Loans ({{ loans.length }})</h3>
        </div>
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th>Loan ID</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Tenure</th>
                <th>Interest Rate</th>
                <th>EMI</th>
                <th>Status</th>
                <th>Applied Date</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngIf="loans.length === 0">
                <td colspan="8" class="text-center p-xl">
                  <div class="empty-state">
                    <span class="material-icons-round">track_changes</span>
                    <h3>No loans found</h3>
                    <p class="text-muted text-sm">You have not submitted any loan applications yet</p>
                  </div>
                </td>
              </tr>
              <tr *ngFor="let l of loans">
                <td class="font-mono text-sm font-semibold">{{ l.loanId }}</td>
                <td>{{ l.loanType }}</td>
                <td class="font-semibold">{{ formatCurrency(l.amount) }}</td>
                <td>{{ l.tenureMonths }} months</td>
                <td>{{ l.interestRate }}%</td>
                <td class="font-semibold text-accent">{{ formatCurrency(l.emiAmount) }}</td>
                <td><span class="badge" [ngClass]="'badge-' + getStatusBadgeClass(l.status)">{{ l.status }}</span></td>
                <td>{{ formatDate(l.appliedDate) }}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class LoanStatusComponent implements OnInit {
  user: User | null = null;
  loans: Loan[] = [];

  constructor(
    private authService: AuthService,
    private storeService: StoreService,
    private utilsService: UtilsService
  ) {}

  ngOnInit() {
    this.user = this.authService.getCurrentUser();
    if (this.user) {
      if (this.authService.isAdmin()) {
        this.loans = this.storeService.getAll<Loan>('loans');
      } else {
        this.loans = this.storeService.getLoansByUser(this.user.userId);
      }
    }
  }

  formatCurrency(amount: number): string {
    return this.utilsService.formatCurrency(amount);
  }

  formatDate(dateStr: string): string {
    return this.utilsService.formatDate(dateStr);
  }

  getStatusBadgeClass(status: string): string {
    return this.utilsService.getStatusBadgeClass(status);
  }
}
